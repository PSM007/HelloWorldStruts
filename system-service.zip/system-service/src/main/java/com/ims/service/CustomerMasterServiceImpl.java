package com.ims.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ims.beans.CustomerDraft;
import com.ims.beans.FinalResponseBean;
import com.ims.beans.ItemMaster;
import com.ims.beans.Response;
import com.ims.constant.CommonConstants;
import com.ims.constant.MessageConstants;
import com.ims.dao.CustomerMasterDAO;

@Service
public class CustomerMasterServiceImpl implements CustomerMasterService {

	private static final Logger LOG = LogManager.getFormatterLogger();

	@Autowired
	public CustomerMasterDAO customerMasterDAO;

	@Override
	public FinalResponseBean<CustomerDraft> addCustomer(String logId, CustomerDraft customerDraft) {
		long startTime = System.currentTimeMillis();

		LOG.info(logId + MessageConstants.NEW_REQUEST);
		LOG.info(logId + CommonConstants.INPUT_START);

		/* PRINT INPUT PARAMETER */
		LOG.info(logId + CommonConstants.INPUT_END);
		Response responseBean = new Response();
		FinalResponseBean<CustomerDraft> finalResponseBean = new FinalResponseBean<CustomerDraft>();

		try {

			/*--------------BUSINESS LOGIC------------------------------*/
			finalResponseBean = customerMasterDAO.addCustomer(logId, customerDraft);
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(logId + CommonConstants.EXCEPTION_STRING_START);
			LOG.error(logId + e);
			LOG.error(logId + CommonConstants.EXCEPTION_STRING_END);

		} finally {

		}
		long endTime = System.currentTimeMillis();
		LOG.info(logId + CommonConstants.EXEC_TIME + (endTime - startTime));
		LOG.info(logId + MessageConstants.SENDING_RESPONSE);
		return finalResponseBean;
	}

	@Override
	public FinalResponseBean<CustomerDraft> getCustomer(String logId, int custCode) {
		long startTime = System.currentTimeMillis();

		LOG.info(logId + MessageConstants.NEW_REQUEST);
		LOG.info(logId + CommonConstants.INPUT_START);

		/* PRINT INPUT PARAMETER */
		LOG.info(logId + CommonConstants.INPUT_END);
		Response responseBean = new Response();
		FinalResponseBean<CustomerDraft> finalResponseBean = new FinalResponseBean<CustomerDraft>();

		try {

			/*--------------BUSINESS LOGIC------------------------------*/
			finalResponseBean = customerMasterDAO.getCustomer(logId, custCode);
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(logId + CommonConstants.EXCEPTION_STRING_START);
			LOG.error(logId + e);
			LOG.error(logId + CommonConstants.EXCEPTION_STRING_END);

		} finally {

		}
		long endTime = System.currentTimeMillis();
		LOG.info(logId + CommonConstants.EXEC_TIME + (endTime - startTime));
		LOG.info(logId + MessageConstants.SENDING_RESPONSE);
		return finalResponseBean;
	}

	@Override
	public FinalResponseBean<CustomerDraft> getAllCustomers(String logId) {
		long startTime = System.currentTimeMillis();

		LOG.info(logId + MessageConstants.NEW_REQUEST);
		LOG.info(logId + CommonConstants.INPUT_START);

		/* PRINT INPUT PARAMETER */
		LOG.info(logId + CommonConstants.INPUT_END);
		Response responseBean = new Response();
		FinalResponseBean<CustomerDraft> finalResponseBean = new FinalResponseBean<CustomerDraft>();

		try {

			/*--------------BUSINESS LOGIC------------------------------*/
			finalResponseBean = customerMasterDAO.getAllCustomers(logId);
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(logId + CommonConstants.EXCEPTION_STRING_START);
			LOG.error(logId + e);
			LOG.error(logId + CommonConstants.EXCEPTION_STRING_END);

		} finally {

		}
		long endTime = System.currentTimeMillis();
		LOG.info(logId + CommonConstants.EXEC_TIME + (endTime - startTime));
		LOG.info(logId + MessageConstants.SENDING_RESPONSE);
		return finalResponseBean;
	}

	@Override
	public FinalResponseBean<CustomerDraft> deleteCustomer(String logId, CustomerDraft customerDraft) {
		long startTime = System.currentTimeMillis();

		LOG.info(logId + MessageConstants.NEW_REQUEST);
		LOG.info(logId + CommonConstants.INPUT_START);

		/* PRINT INPUT PARAMETER */
		LOG.info(logId + CommonConstants.INPUT_END);
		Response responseBean = new Response();
		FinalResponseBean<CustomerDraft> finalResponseBean = new FinalResponseBean<CustomerDraft>();

		try {

			/*--------------BUSINESS LOGIC------------------------------*/
			finalResponseBean = customerMasterDAO.deleteCustomer(logId, customerDraft);
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(logId + CommonConstants.EXCEPTION_STRING_START);
			LOG.error(logId + e);
			LOG.error(logId + CommonConstants.EXCEPTION_STRING_END);

		} finally {

		}
		long endTime = System.currentTimeMillis();
		LOG.info(logId + CommonConstants.EXEC_TIME + (endTime - startTime));
		LOG.info(logId + MessageConstants.SENDING_RESPONSE);
		return finalResponseBean;
	}

	@Override
	public FinalResponseBean<CustomerDraft> updateCustomer(String logId, CustomerDraft customerDraft) {
		long startTime = System.currentTimeMillis();

		LOG.info(logId + MessageConstants.NEW_REQUEST);
		LOG.info(logId + CommonConstants.INPUT_START);

		/* PRINT INPUT PARAMETER */
		LOG.info(logId + CommonConstants.INPUT_END);
		Response responseBean = new Response();
		FinalResponseBean<CustomerDraft> finalResponseBean = new FinalResponseBean<CustomerDraft>();

		try {

			/*--------------BUSINESS LOGIC------------------------------*/
			finalResponseBean = customerMasterDAO.updateCustomer(logId, customerDraft);
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(logId + CommonConstants.EXCEPTION_STRING_START);
			LOG.error(logId + e);
			LOG.error(logId + CommonConstants.EXCEPTION_STRING_END);

		} finally {

		}
		long endTime = System.currentTimeMillis();
		LOG.info(logId + CommonConstants.EXEC_TIME + (endTime - startTime));
		LOG.info(logId + MessageConstants.SENDING_RESPONSE);
		return finalResponseBean;
	}

}
