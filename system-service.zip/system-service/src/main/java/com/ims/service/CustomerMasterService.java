package com.ims.service;

import com.ims.beans.CustomerDraft;
import com.ims.beans.FinalResponseBean;

public interface CustomerMasterService {

	FinalResponseBean<CustomerDraft> addCustomer(String logId, CustomerDraft customerDraft);
	FinalResponseBean<CustomerDraft> getCustomer(String logId, int custCode);
	FinalResponseBean<CustomerDraft> getAllCustomers(String logId);
	FinalResponseBean<CustomerDraft> deleteCustomer(String logId, CustomerDraft customerDraft);
	FinalResponseBean<CustomerDraft> updateCustomer(String logId, CustomerDraft customerDraft);
}
