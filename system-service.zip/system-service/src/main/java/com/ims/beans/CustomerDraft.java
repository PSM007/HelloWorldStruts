package com.ims.beans;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "cust_draft")
public class CustomerDraft {
	@Column(name = "CD_CUST_CODE")
	private String custCode;

	@Column(name = "'CD_NAME'")
	private String custName;

	@Column(name = "CD_TS_CREATED")
	private Date cdTsCreated;

	@Column(name = "CD_CREATED_BY")
	private Date cdCreatedBy;

	@Column(name = "CD_TS_EDITED")
	private Date cdTsEdited;

	@Column(name = "CD_DELETED_FLG")
	private String deletedFlag;

	@Column(name = "CD_PAN_NO")
	private String custPanNo;

	@Column(name = "CD_COMPANY_CODE")
	private String companyCode;

	@Column(name = "CD_REMARKS")
	private String custRemarks;

	@Column(name = "CD_BILL_ADDR")
	private String billAddress;
	@Column(name = "CD_BILL_CITY")
	private String billCity;
	@Column(name = "CD_BILL_STATE")
	private String billState;
	@Column(name = "CD_BILL_PIN")
	private String billPin;
	@Column(name = "CD_SHIP_ADDR")
	private String shipAddress;
	@Column(name = "CD_SHIP_CITY")
	private String shipCity;
	@Column(name = "CD_SHIP_STATE")
	private String shipState;
	@Column(name = "CD_SHIP_PIN")
	private String shipPin;
	@Column(name = "CD_CONTACT_1")
	private String contactPersonOne;
	@Column(name = "CD_CONTACT_2")
	private String contactPersonTwo;
	@Column(name = "CD_TEL_1")
	private String telNoOne;
	@Column(name = "CD_TEL_2")
	private String telNoTwo;
	@Column(name = "CD_TEL_3")
	private String telNoThree;
	@Column(name = "CD_EMAIL")
	private String custEmail;
	@Column(name = "CD_SOURCE")
	private String custSource;
	@Column(name = "CD_AREA_LOCATION")
	private String custAreaLocation;
	@Column(name = "CD_BLACK_LISTED")
	private String custBlackListed;

	@Column(name = "CD_GST_NO")
	private String custGSTNo;

	public String getCustCode() {
		return custCode;
	}

	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public Date getCdTsCreated() {
		return cdTsCreated;
	}

	public void setCdTsCreated(Date cdTsCreated) {
		this.cdTsCreated = cdTsCreated;
	}

	public Date getCdCreatedBy() {
		return cdCreatedBy;
	}

	public void setCdCreatedBy(Date cdCreatedBy) {
		this.cdCreatedBy = cdCreatedBy;
	}

	public Date getCdTsEdited() {
		return cdTsEdited;
	}

	public void setCdTsEdited(Date cdTsEdited) {
		this.cdTsEdited = cdTsEdited;
	}

	public String getDeletedFlag() {
		return deletedFlag;
	}

	public void setDeletedFlag(String deletedFlag) {
		this.deletedFlag = deletedFlag;
	}

	public String getCustPanNo() {
		return custPanNo;
	}

	public void setCustPanNo(String custPanNo) {
		this.custPanNo = custPanNo;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getCustRemarks() {
		return custRemarks;
	}

	public void setCustRemarks(String custRemarks) {
		this.custRemarks = custRemarks;
	}

	public String getBillAddress() {
		return billAddress;
	}

	public void setBillAddress(String billAddress) {
		this.billAddress = billAddress;
	}

	public String getBillCity() {
		return billCity;
	}

	public void setBillCity(String billCity) {
		this.billCity = billCity;
	}

	public String getBillState() {
		return billState;
	}

	public void setBillState(String billState) {
		this.billState = billState;
	}

	public String getBillPin() {
		return billPin;
	}

	public void setBillPin(String billPin) {
		this.billPin = billPin;
	}

	public String getShipAddress() {
		return shipAddress;
	}

	public void setShipAddress(String shipAddress) {
		this.shipAddress = shipAddress;
	}

	public String getShipCity() {
		return shipCity;
	}

	public void setShipCity(String shipCity) {
		this.shipCity = shipCity;
	}

	public String getShipState() {
		return shipState;
	}

	public void setShipState(String shipState) {
		this.shipState = shipState;
	}

	public String getShipPin() {
		return shipPin;
	}

	public void setShipPin(String shipPin) {
		this.shipPin = shipPin;
	}

	public String getContactPersonOne() {
		return contactPersonOne;
	}

	public void setContactPersonOne(String contactPersonOne) {
		this.contactPersonOne = contactPersonOne;
	}

	public String getContactPersonTwo() {
		return contactPersonTwo;
	}

	public void setContactPersonTwo(String contactPersonTwo) {
		this.contactPersonTwo = contactPersonTwo;
	}

	public String getTelNoOne() {
		return telNoOne;
	}

	public void setTelNoOne(String telNoOne) {
		this.telNoOne = telNoOne;
	}

	public String getTelNoTwo() {
		return telNoTwo;
	}

	public void setTelNoTwo(String telNoTwo) {
		this.telNoTwo = telNoTwo;
	}

	public String getTelNoThree() {
		return telNoThree;
	}

	public void setTelNoThree(String telNoThree) {
		this.telNoThree = telNoThree;
	}

	public String getCustEmail() {
		return custEmail;
	}

	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}

	public String getCustSource() {
		return custSource;
	}

	public void setCustSource(String custSource) {
		this.custSource = custSource;
	}

	public String getCustAreaLocation() {
		return custAreaLocation;
	}

	public void setCustAreaLocation(String custAreaLocation) {
		this.custAreaLocation = custAreaLocation;
	}

	public String getCustBlackListed() {
		return custBlackListed;
	}

	public void setCustBlackListed(String custBlackListed) {
		this.custBlackListed = custBlackListed;
	}

	public String getCustGSTNo() {
		return custGSTNo;
	}

	public void setCustGSTNo(String custGSTNo) {
		this.custGSTNo = custGSTNo;
	}

	@Override
	public String toString() {
		return "CustomerDraft [custCode=" + custCode + ", custName=" + custName + ", cdTsCreated=" + cdTsCreated
				+ ", cdCreatedBy=" + cdCreatedBy + ", cdTsEdited=" + cdTsEdited + ", deletedFlag=" + deletedFlag
				+ ", custPanNo=" + custPanNo + ", companyCode=" + companyCode + ", custRemarks=" + custRemarks
				+ ", billAddress=" + billAddress + ", billCity=" + billCity + ", billState=" + billState + ", billPin="
				+ billPin + ", shipAddress=" + shipAddress + ", shipCity=" + shipCity + ", shipState=" + shipState
				+ ", shipPin=" + shipPin + ", contactPersonOne=" + contactPersonOne + ", contactPersonTwo="
				+ contactPersonTwo + ", telNoOne=" + telNoOne + ", telNoTwo=" + telNoTwo + ", telNoThree=" + telNoThree
				+ ", custEmail=" + custEmail + ", custSource=" + custSource + ", custAreaLocation=" + custAreaLocation
				+ ", custBlackListed=" + custBlackListed + ", custGSTNo=" + custGSTNo + "]";
	}

}
