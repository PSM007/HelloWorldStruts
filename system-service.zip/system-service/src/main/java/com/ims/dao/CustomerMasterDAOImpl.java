package com.ims.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.ims.beans.CustomerDraft;
import com.ims.beans.FinalResponseBean;
import com.ims.beans.Item;
import com.ims.beans.ItemMaster;
import com.ims.beans.Response;
import com.ims.constant.CommonConstants;
import com.ims.constant.MessageConstants;
import com.ims.helper.HibernateUtil;

@Repository
public class CustomerMasterDAOImpl implements CustomerMasterDAO {
	private static final Logger LOG = LogManager.getFormatterLogger();

	@Override
	public FinalResponseBean<CustomerDraft> addCustomer(String logId, CustomerDraft customerDraft) {
		Session session = null;
		Response responseBean = new Response();
		FinalResponseBean<CustomerDraft> finalResponseBean = new FinalResponseBean<CustomerDraft>();
		List<CustomerDraft> customerDraftsList = new ArrayList<CustomerDraft>();
		try {
			session = HibernateUtil.getSessionFactory(logId).openSession();
			session.beginTransaction();
			responseBean.setRespCode(CommonConstants.SUCCESSS_CODE);
			responseBean.setRespMsg(MessageConstants.ITEMS_ITEM_ADD_SUCCESS);
			session.save(customerDraft);
			session.getTransaction().commit();

			CustomerDraft customerDraftBean = new CustomerDraft();
			customerDraftBean = session.get(CustomerDraft.class, customerDraft.getCustCode());
			customerDraftsList.add(customerDraftBean);					
			finalResponseBean.setData(customerDraftsList);
			
			responseBean.setRespCode(CommonConstants.SUCCESSS_CODE);
			responseBean.setRespMsg(MessageConstants.ITEMS_GET_ALL_SUCCESS);
			finalResponseBean.setResponse(responseBean);
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(logId + CommonConstants.EXCEPTION_STRING_START);
			LOG.error(logId + e);
			LOG.error(logId + CommonConstants.EXCEPTION_STRING_END);
			responseBean.setRespCode(CommonConstants.FAILURE_CODE);
			responseBean.setRespMsg(MessageConstants.ITEMS_ITEM_ADD_ERROR);

		} finally {
			/* closing session */
			if (session != null) {
				session.close();
			}
		}
		return finalResponseBean;
	}

	@Override
	public FinalResponseBean<CustomerDraft> getCustomer(String logId, int custCode) {
		Session session = null;
		Response responseBean = new Response();
		FinalResponseBean<CustomerDraft> finalResponseBean = new FinalResponseBean<CustomerDraft>();
		List<CustomerDraft> customerDraftsList = new ArrayList<CustomerDraft>();
		try {
			session = HibernateUtil.getSessionFactory(logId).openSession();
			session.beginTransaction();
			responseBean.setRespCode(CommonConstants.SUCCESSS_CODE);
			responseBean.setRespMsg(MessageConstants.ITEMS_ITEM_ADD_SUCCESS);
			

			CustomerDraft customerDraftBean = new CustomerDraft();
			customerDraftBean = session.get(CustomerDraft.class, custCode);
			customerDraftsList.add(customerDraftBean);					
			finalResponseBean.setData(customerDraftsList);
			
			responseBean.setRespCode(CommonConstants.SUCCESSS_CODE);
			responseBean.setRespMsg(MessageConstants.ITEMS_GET_ALL_SUCCESS);
			finalResponseBean.setResponse(responseBean);
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(logId + CommonConstants.EXCEPTION_STRING_START);
			LOG.error(logId + e);
			LOG.error(logId + CommonConstants.EXCEPTION_STRING_END);
			responseBean.setRespCode(CommonConstants.FAILURE_CODE);
			responseBean.setRespMsg(MessageConstants.ITEMS_ITEM_ADD_ERROR);

		} finally {
			/* closing session */
			if (session != null) {
				session.close();
			}
		}
		return finalResponseBean;
	}

	@Override
	public FinalResponseBean<CustomerDraft> getAllCustomers(String logId) {
		Session session = null;
		Response responseBean = new Response();
		FinalResponseBean<CustomerDraft> finalResponseBean = new FinalResponseBean<CustomerDraft>();
		List<CustomerDraft> customerDraftsList = new ArrayList<CustomerDraft>();
		try {
			session = HibernateUtil.getSessionFactory(logId).openSession();
			session.beginTransaction();
			responseBean.setRespCode(CommonConstants.SUCCESSS_CODE);
			responseBean.setRespMsg(MessageConstants.ITEMS_ITEM_ADD_SUCCESS);
			
			Query query = session.createQuery(" from CustomerDraft");
			customerDraftsList =(List<CustomerDraft>) query.list();					
			finalResponseBean.setData(customerDraftsList);
			
			responseBean.setRespCode(CommonConstants.SUCCESSS_CODE);
			responseBean.setRespMsg(MessageConstants.ITEMS_GET_ALL_SUCCESS);
			finalResponseBean.setResponse(responseBean);
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(logId + CommonConstants.EXCEPTION_STRING_START);
			LOG.error(logId + e);
			LOG.error(logId + CommonConstants.EXCEPTION_STRING_END);
			responseBean.setRespCode(CommonConstants.FAILURE_CODE);
			responseBean.setRespMsg(MessageConstants.ITEMS_ITEM_ADD_ERROR);

		} finally {
			/* closing session */
			if (session != null) {
				session.close();
			}
		}
		return finalResponseBean;
	}

	@Override
	public FinalResponseBean<CustomerDraft> deleteCustomer(String logId, CustomerDraft customerDraft) {
		Session session = null;
		Response responseBean = new Response();
		FinalResponseBean<CustomerDraft> finalResponseBean = new FinalResponseBean<CustomerDraft>();
		List<CustomerDraft> customerDraftsList = new ArrayList<CustomerDraft>();
		try {
			session = HibernateUtil.getSessionFactory(logId).openSession();
			session.beginTransaction();
			responseBean.setRespCode(CommonConstants.SUCCESSS_CODE);
			responseBean.setRespMsg(MessageConstants.ITEMS_ITEM_ADD_SUCCESS);
			session.save(customerDraft);
			session.getTransaction().commit();

			CustomerDraft customerDraftBean = new CustomerDraft();
			customerDraftBean = session.get(CustomerDraft.class, customerDraft.getCustCode());
			customerDraftsList.add(customerDraftBean);					
			finalResponseBean.setData(customerDraftsList);
			
			responseBean.setRespCode(CommonConstants.SUCCESSS_CODE);
			responseBean.setRespMsg(MessageConstants.ITEMS_GET_ALL_SUCCESS);
			finalResponseBean.setResponse(responseBean);
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(logId + CommonConstants.EXCEPTION_STRING_START);
			LOG.error(logId + e);
			LOG.error(logId + CommonConstants.EXCEPTION_STRING_END);
			responseBean.setRespCode(CommonConstants.FAILURE_CODE);
			responseBean.setRespMsg(MessageConstants.ITEMS_ITEM_ADD_ERROR);

		} finally {
			/* closing session */
			if (session != null) {
				session.close();
			}
		}
		return finalResponseBean;
	}

	@Override
	public FinalResponseBean<CustomerDraft> updateCustomer(String logId, CustomerDraft customerDraft) {
		Session session = null;
		Response responseBean = new Response();
		FinalResponseBean<CustomerDraft> finalResponseBean = new FinalResponseBean<CustomerDraft>();
		List<CustomerDraft> customerDraftsList = new ArrayList<CustomerDraft>();
		try {
			session = HibernateUtil.getSessionFactory(logId).openSession();
			session.beginTransaction();
			responseBean.setRespCode(CommonConstants.SUCCESSS_CODE);
			responseBean.setRespMsg(MessageConstants.ITEMS_ITEM_ADD_SUCCESS);
			session.save(customerDraft);
			session.getTransaction().commit();

			CustomerDraft customerDraftBean = new CustomerDraft();
			customerDraftBean = session.get(CustomerDraft.class, customerDraft.getCustCode());
			customerDraftsList.add(customerDraftBean);					
			finalResponseBean.setData(customerDraftsList);
			
			responseBean.setRespCode(CommonConstants.SUCCESSS_CODE);
			responseBean.setRespMsg(MessageConstants.ITEMS_GET_ALL_SUCCESS);
			finalResponseBean.setResponse(responseBean);
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(logId + CommonConstants.EXCEPTION_STRING_START);
			LOG.error(logId + e);
			LOG.error(logId + CommonConstants.EXCEPTION_STRING_END);
			responseBean.setRespCode(CommonConstants.FAILURE_CODE);
			responseBean.setRespMsg(MessageConstants.ITEMS_ITEM_ADD_ERROR);

		} finally {
			/* closing session */
			if (session != null) {
				session.close();
			}
		}
		return finalResponseBean;
	}

}
