package com.ims.dao;

import com.ims.beans.UserDetails;

public interface LoginDAO {

	UserDetails validateUserDAO(String logId, String userId, String password);
}
